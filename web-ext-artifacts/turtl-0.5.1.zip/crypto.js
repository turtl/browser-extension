// a stupid placeholder that is required because FF doesn't let us catch{}
// conditions thrown by a missing require() lib.


